Description: This supplementary material contains a PDF document and a video. The PDF document contains symbol definitions, implementation details and additional discussion. The video summarizes our work and shows a demo of our system.
Size: 26MB
Player information: The video can play in any video player.
Packing list: gavideo.mp4; supplementary.pdf